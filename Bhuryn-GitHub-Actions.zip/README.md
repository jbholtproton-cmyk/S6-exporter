# Bhuryn Siege stats export

A manual GitHub Actions workflow for the public Ubisoft/PC username **Bhuryn**
(account ID `2d86dc16-9c1b-4947-b283-4e6e909ccd6f`).

**Live access from GitHub Actions has NOT been verified.** This is an execution
setup, not proof that Tracker accepts requests from GitHub's servers. A 403 or
ACCESS_DENIED result is a failed refresh, not zero statistics.

## Browser-only setup in your existing GitHub account

1. Create a new private repository named `siege-stats`. Initialize it with a README.
   An existing repository also works, but check for conflicting file names first.
2. Add `export-bhuryn.cjs` at the repository root using **Add file > Upload files**.
3. Use **Add file > Create new file**. Enter the full filename
   `.github/workflows/fetch-stats.yml`. Paste in the contents of the workflow file
   from this package, then commit to the default branch.
4. Open **Actions > Export Bhuryn Siege stats > Run workflow**. Select the default
   branch and confirm. No terminal, local Node.js installation, Ubisoft password,
   cookies, 2FA codes, or manually supplied API tokens are needed.
5. Open the completed run. Read its summary, and under **Artifacts** download
   `bhuryn-stats-<run-number>-<attempt>` for any JSON and diagnostic logs produced.

When adding via Git or GitHub Desktop instead, copy the *contents* of this folder
into your repository, including the hidden `.github` directory. Do not upload this
ZIP as a single repository file: the workflow and exporter must be individual files
in the paths shown above. Do not put a `bhuryn-github/` wrapper folder around them.

The workflow file must be on the default branch before the Run workflow button
appears. If Actions is disabled by your account/organization policy, an authorized
repository administrator must enable the appropriate actions; this package does not
change those settings.

## What runs

The workflow uses a GitHub-hosted Ubuntu runner, installs a Node.js 24 release
satisfying `>=24.15.0 <25`, fetches the pinned source of `hmes98318/r6s-stats-api`,
installs its lockfile dependencies (including its managed Chromium browser), installs
Linux browser libraries, builds the package, and runs this exporter.

Upstream revision: `29fad493c4265a718720818d928083c63c50e095`.
The source manifest inspected for that project describes API v2.0.0. This workflow
builds the pinned source instead of assuming the same version is published on npm.
The current official GitHub actions are referenced with their v7 major tags.

It requests overview, recorded seasons, current-season Quick Match/Ranked/Unranked,
default-filter operators and maps, and the first page of recent matches. Data
coverage and filter labels must be checked before comparing with Stats.cc.
Explicit 3v3 support is not established. The first match page is not an all-time
personal-best lookup. Export time is not the latest played-match time.

The exporter has a three-minute total request watchdog. The job has a twelve-minute
cap including installation/build. One failed overview/access-denied request stops
the export; it does not rotate IP addresses or repeatedly retry challenges.
Available outputs are retained for 14 days, subject to repository retention limits.
No recurring schedule has been added. No repository files or account settings are
changed by the workflow; its contents permission is read-only.

Dependency installation/build executes third-party code from the pinned project
and its lockfile dependencies. Do not add credentials to this test. GitHub Actions
usage and artifact storage count toward the account's allowance/billing; a private
repository does not imply unlimited free runs.

## Local validation included

`node --test test-exporter.cjs` runs fabricated-data tests with no network calls.
These validate the wrapper's complete, partial, denied, missing-API and null-data
paths. They do not validate a real Tracker request or a hosted browser launch.

## Source documentation

- Client source: https://github.com/hmes98318/r6s-stats-api
- Client manifest: https://github.com/hmes98318/r6s-stats-api/blob/29fad493c4265a718720818d928083c63c50e095/package.json
- Create repository: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- Upload files: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- Run manually: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- Download artifacts: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
- Actions billing: https://docs.github.com/en/billing/concepts/product-billing/github-actions
- Node setup: https://github.com/actions/setup-node
- Checkout: https://github.com/actions/checkout
- Artifact upload: https://github.com/actions/upload-artifact
- Playwright CI: https://playwright.dev/docs/ci-intro
