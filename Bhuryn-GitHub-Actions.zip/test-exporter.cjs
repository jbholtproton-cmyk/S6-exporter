// Offline tests only: all client responses are fabricated.
'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const {collect, makeReport, SECTIONS} = require('./export-bhuryn.cjs');

function fakeClient(overrides = {}) {
  const client = {};
  for (const [, method] of SECTIONS) {
    client[method] = async (platform, player) => {
      assert.equal(platform, 'ubi');
      assert.equal(player, 'Bhuryn');
      return {source: 'fabricated-test-data', sourceUrl: 'https://example.invalid/test', fetchedAt: '2026-01-01T00:00:00Z', data: {kills: 0, deaths: null}};
    };
  }
  return Object.assign(client, overrides);
}
const noop = () => {};

test('complete run retains source envelope, zero and null', async () => {
  const report = await collect(fakeClient(), makeReport(), noop, noop);
  assert.equal(report.status, 'complete');
  assert.equal(Object.keys(report.sections).length, 8);
  assert.equal(report.sections.overview.result.data.kills, 0);
  assert.equal(report.sections.overview.result.data.deaths, null);
});

test('denied overview stops without requesting other endpoints', async () => {
  let extraCalls = 0;
  const client = fakeClient({
    getOverview: async () => {throw Object.assign(new Error('Denied'), {code: 'ACCESS_DENIED', status: 403});},
    getSeasons: async () => {extraCalls++; return {data: {}};}
  });
  const report = await collect(client, makeReport(), noop, noop);
  assert.equal(report.status, 'failed');
  assert.equal(extraCalls, 0);
  assert.equal(report.sections.overview.error.status, 403);
  assert.equal(report.sections.seasons.status, 'not_attempted');
});

test('nonfatal later parse error preserves partial results', async () => {
  const report = await collect(fakeClient({getMaps: async () => ({wrong: true})}), makeReport(), noop, noop);
  assert.equal(report.status, 'partial');
  assert.equal(report.sections.mapsDefaultFilters.error.code, 'PARSE_ERROR');
  assert.equal(report.sections.recentMatchesFirstPage.status, 'retrieved');
});

test('absent API is reported instead of invented results', async () => {
  const report = await collect(fakeClient({getOverview: undefined}), makeReport(), noop, noop);
  assert.equal(report.status, 'failed');
  assert.equal(report.sections.overview.error.code, 'UNSUPPORTED_PACKAGE');
});

test('no current-season segment stays null, never zero', async () => {
  const report = await collect(fakeClient({getQuickMatch: async () => ({data: null})}), makeReport(), noop, noop);
  assert.equal(report.status, 'complete');
  assert.equal(report.sections.quickMatchCurrentSeason.result.data, null);
});

test('later access denial ends further requests but retains retrieved sections', async () => {
  const report = await collect(fakeClient({getQuickMatch: async () => {throw Object.assign(new Error('Denied'), {code: 'ACCESS_DENIED'});}}), makeReport(), noop, noop);
  assert.equal(report.status, 'partial');
  assert.equal(report.sections.overview.status, 'retrieved');
  assert.equal(report.sections.rankedCurrentSeason.status, 'not_attempted');
});
